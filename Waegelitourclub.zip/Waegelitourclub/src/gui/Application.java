package gui;

/**
 * Created by Jannik on 19.01.2017.
 */
public class Application {

    public static void main(String[] args) {
        System.out.println("Startet!");
        GUILogin gl = new GUILogin();
        gl.baueGUI();
    }

}
