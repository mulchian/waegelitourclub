package gui;

import verwaltung.AdminTourVerwaltung;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by Arunan on 19.01.2017.
 */
public class GUIAdminTour extends JPanel implements ActionListener, KeyListener {

    //Über Verwaltung
    //private Speicher speicher;

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public JPanel jPanel = new JPanel();
    public AdminTourVerwaltung management = new AdminTourVerwaltung();
    ArrayList<String> txaTourenListe;

    JLabel lblHeader = new JLabel("Tour Übersicht");
    JLabel lblName = new JLabel("Name");
    JLabel lblStreckeVon = new JLabel("Von");
    JLabel lblSteckeBis = new JLabel("Bis");
    JLabel lblKM = new JLabel("Anzahl KM");
    JLabel lblNeueName = new JLabel("Name: ");
    JLabel lblNeueStreckeVon = new JLabel("Von: ");
    JLabel lblNeueSteckeBis = new JLabel("Bis: ");
    JLabel lblNeueKM = new JLabel("Anzahl KM: ");
    JTextField txfVon = new JTextField();
    JTextField txfBis = new JTextField();
    JTextField txfLaenge = new JTextField();
    JButton btnHinzufuegen = new JButton("Hinzufügen");
    JButton btnLoeschen = new JButton(("Alle Touren Löschen"));
    JLabel lblNeueTour = new JLabel("Neue Tour");
    JTextField txfName = new JTextField();
    JTextArea txaTourList = new JTextArea();

    public JPanel baueGUI() throws Exception {

        jPanel.setSize(500, 350);
        jPanel.setLayout(null);

        txaTourenListe = management.getTouren();
        for (String zeile : txaTourenListe) {
            txaTourList.append(zeile + "\n");
        }
        txaTourList.setFont(new Font("Lucida Console", Font.PLAIN, 12));

        lblHeader.setBounds(150, 10, 100, 20);
        lblName.setBounds(25, 50, 100, 20);
        lblStreckeVon.setBounds(85, 50, 100, 20);
        lblSteckeBis.setBounds(130, 50, 100, 20);
        lblKM.setBounds(180, 50, 100, 20);
        lblNeueName.setBounds(280, 75, 100, 20);
        lblNeueStreckeVon.setBounds(280, 100, 100, 20);
        lblNeueSteckeBis.setBounds(280, 125, 100, 20);
        lblNeueKM.setBounds(280, 150, 100, 20);
        txaTourList.setBounds(25, 75, 225, 150);
        lblNeueTour.setBounds(370, 50, 100, 20);
        txfName.setBounds(350, 75, 120, 20);
        txfVon.setBounds(350, 100, 120, 20);
        txfBis.setBounds(350, 125, 120, 20);
        txfLaenge.setBounds(350, 150, 120, 20);
        btnHinzufuegen.setBounds(350, 175, 100, 20);
        btnLoeschen.setBounds(325, 200, 150,20);

        btnHinzufuegen.addActionListener(this);
        btnLoeschen.addActionListener(this);

        txfName.addKeyListener(this);
        txfVon.addKeyListener(this);
        txfBis.addKeyListener(this);
        txfLaenge.addKeyListener(this);

        jPanel.add(lblHeader);
        jPanel.add(lblStreckeVon);
        jPanel.add(lblName);
        jPanel.add(lblSteckeBis);
        jPanel.add(lblKM);
        jPanel.add(lblNeueStreckeVon);
        jPanel.add(lblNeueName);
        jPanel.add(lblNeueSteckeBis);
        jPanel.add(lblNeueKM);
        jPanel.add(txaTourList);
        jPanel.add(txfVon);
        jPanel.add(txfBis);
        jPanel.add(txfLaenge);
        jPanel.add(btnHinzufuegen);
        jPanel.add(btnLoeschen);
        jPanel.add(lblNeueTour);
        jPanel.add(txfName);

        jPanel.setMinimumSize(new Dimension(500, 350));
        jPanel.setVisible(true);

        return jPanel;
    }

    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == btnHinzufuegen) {
            String[] str = txaTourList.getText().split("\\r?\\n");
            txaTourenListe = new ArrayList<String>(Arrays.asList(str));
            txaTourList.append(String.format("%1$-10s", txfName.getText()) + "|" + String.format("%1$-10s", txfVon.getText()) + "|" +
                    String.format("%1$-10s", txfBis.getText()) + "|" + String.format("%1$-10s", txfLaenge.getText()) + "|\n");
            GUITour.txaTourList.append(String.format("%1$-10s", txfName.getText()) + "|" + String.format("%1$-10s", txfVon.getText()) + "|" +
                    String.format("%1$-10s", txfBis.getText()) + "|" + String.format("%1$-10s", txfLaenge.getText()) + "|\n");
            try {
                management.fuegeTourHinzu(txaTourenListe, txfName.getText(), txfVon.getText(), txfBis.getText(), txfLaenge.getText());
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
        if (e.getSource() == btnLoeschen) {

        }
    }

    public void keyTyped(KeyEvent e) {
        if (txfName.getText().length() >= 10) {
            e.consume();
        } else if (txfVon.getText().length() >= 10) {
            e.consume();
        } else if (txfBis.getText().length() >= 10) {
            e.consume();
        } else if (txfLaenge.getText().length() >= 10) {
            e.consume();
        }
    }

    public void keyPressed(KeyEvent e) {

    }

    public void keyReleased(KeyEvent e) {

    }
}
