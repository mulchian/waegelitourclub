package gui;

import verwaltung.WaegeliVerwaltung;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Created by Jannik on 19.01.2017.
 */
public class GUIWaegeli implements ActionListener {

    //Speicher über die Verwaltung

    private JPanel jPanel = new JPanel();
    private WaegeliVerwaltung management = new WaegeliVerwaltung();
    private GUIWaegeliAnlegen guiWaegeliAnlegen = new GUIWaegeliAnlegen();
    private ArrayList<String> waegeliListe;

    private static int counter = 0;

    private JLabel lblHeader = new JLabel("Waegeli Übersicht");
    private JLabel lblWaegelinutzer = new JLabel("Waegelinutzer: ");
    private JLabel lblWaegeliname = new JLabel("Waegeliname: ");
    private JLabel lblWaegelifarbe = new JLabel("Waegelifarbe: ");
    private JLabel lblWaegelitreibstoff = new JLabel("Waegelitreibstoff: ");
    private JLabel lblWaegelistaerke = new JLabel("Waegelistärke: ");
    private JLabel lblWaegelinutzerAnzeige = new JLabel();
    private JLabel lblWaegelinameAnzeige = new JLabel();
    private JLabel lblWaegelifarbeAnzeige = new JLabel();
    private JLabel lblWaegelitreibstoffAnzeige = new JLabel();
    private JLabel lblWaegelistaerkeAnzeige = new JLabel();

    private JButton btnNext = new JButton("Nächster Waegeli");
    private JButton btnAnlegen = new JButton("Waegeli anlegen");
    private JButton btnBearbeiten = new JButton("Waegeli bearbeiten");

    private JLabel lblIcon = new JLabel();

    public JPanel baueGUI() throws Exception{
        jPanel.setSize(500, 350);
        jPanel.setLayout(null);
        
        this.setWaegeli();

        lblHeader.setBounds(150, 10, 150, 20);
        lblIcon.setBounds(25, 75, 225, 150);
        btnAnlegen.setBounds(25, 250, 150, 30);
        btnBearbeiten.setBounds(200, 250, 150, 30);
        btnNext.setBounds(300, 200, 150, 30);
        lblWaegelinutzer.setBounds(260, 75, 120, 20);
        lblWaegeliname.setBounds(260, 100, 120, 20);
        lblWaegelifarbe.setBounds(260, 125, 120, 20);
        lblWaegelitreibstoff.setBounds(260, 150, 120, 20);
        lblWaegelistaerke.setBounds(260, 175, 120, 20);
        lblWaegelinutzerAnzeige.setBounds(370, 75, 100, 20);
        lblWaegelinameAnzeige.setBounds(370, 100, 100, 20);
        lblWaegelifarbeAnzeige.setBounds(370, 125, 100, 20);
        lblWaegelitreibstoffAnzeige.setBounds(370, 150, 100, 20);
        lblWaegelistaerkeAnzeige.setBounds(370, 175, 100, 20);

        jPanel.add(lblHeader);
        jPanel.add(lblIcon);
        jPanel.add(lblWaegelinutzer);
        jPanel.add(lblWaegeliname);
        jPanel.add(lblWaegelifarbe);
        jPanel.add(lblWaegelitreibstoff);
        jPanel.add(lblWaegelistaerke);
        jPanel.add(lblWaegelinutzerAnzeige);
        jPanel.add(lblWaegelinameAnzeige);
        jPanel.add(lblWaegelifarbeAnzeige);
        jPanel.add(lblWaegelitreibstoffAnzeige);
        jPanel.add(lblWaegelistaerkeAnzeige);
        jPanel.add(btnAnlegen);
        jPanel.add(btnBearbeiten);
        jPanel.add(btnNext);

        btnAnlegen.addActionListener(this);
        btnBearbeiten.addActionListener(this);
        btnNext.addActionListener(this);

        jPanel.setMinimumSize(new Dimension(500, 350));

        return jPanel;
    }
    
    private void setWaegeli() throws Exception {
        waegeliListe = management.getWaegelis();
        String zeile = waegeliListe.get(counter);
        String[] waegeliDaten = zeile.split("\\|");
        lblWaegelinutzerAnzeige.setText(waegeliDaten[0]);
        lblWaegelinameAnzeige.setText(waegeliDaten[1]);
        lblWaegelifarbeAnzeige.setText(waegeliDaten[2]);
        lblWaegelitreibstoffAnzeige.setText(waegeliDaten[3]);
        lblWaegelistaerkeAnzeige.setText(waegeliDaten[4]);
        lblIcon.setIcon(management.setImageIcon(waegeliDaten[5]));
        if((counter + 1) < waegeliListe.size()) {
            counter++;
        } else {
            counter = 0;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.btnAnlegen) {
            try {
                guiWaegeliAnlegen.baueGUI();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
        if (e.getSource() == this.btnBearbeiten) {

        }
        if (e.getSource() == this.btnNext) {
            try {
                setWaegeli();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }
}
