package gui;

import javax.swing.*;
import java.awt.*;

/**
 * Created by Jannik on 20.01.2017.
 */
public class GUIAdmin {

    JPanel jPanel = new JPanel();

    public JPanel baueGUI() {
        //Mitgliederliste
        //Mitglieder hinzufügen (CheckButton, ob Admin oder nicht)

        jPanel.setSize(500, 350);
        jPanel.setLayout(null);

        //Hier coden!

        jPanel.setMinimumSize(new Dimension(500, 350));
        jPanel.setVisible(true);

        return jPanel;
    }
}
