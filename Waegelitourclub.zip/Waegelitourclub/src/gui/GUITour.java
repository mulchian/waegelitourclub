package gui;

import verwaltung.MitgliedTourVerwaltung;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * Created by Arunan on 19.01.2017.
 */
public class GUITour {

    //Über Verwaltung
    //private Speicher speicher;

    public JPanel jPanel = new JPanel();
    public MitgliedTourVerwaltung management = new MitgliedTourVerwaltung();
    private ArrayList<String> txaTourenListe;

    private JLabel lblHeader = new JLabel("Tour Übersicht");
    private JLabel lblName = new JLabel("Name");
    private JLabel lblStreckeVon = new JLabel("Von");
    private JLabel lblSteckeBis = new JLabel("Bis");
    private JLabel lblKM = new JLabel("Anzahl KM");
    public static JTextArea txaTourList = new JTextArea();

    public JPanel baueGUI() throws Exception {

        jPanel.setSize(500, 350);
        jPanel.setLayout(null);

        txaTourenListe = management.getTouren();
        for (String zeile : txaTourenListe) {
            txaTourList.append(zeile + "\n");
        }
        txaTourList.setFont(new Font("Lucida Console", Font.PLAIN, 12));

        lblHeader.setBounds(180, 10, 100, 20);
        lblName.setBounds(80, 50, 100, 20);
        lblStreckeVon.setBounds(160, 50, 100, 20);
        lblSteckeBis.setBounds(230, 50, 100, 20);
        lblKM.setBounds(310, 50, 100, 20);
        txaTourList.setBounds(75, 75, 300, 150);

        jPanel.add(lblHeader);
        jPanel.add(lblStreckeVon);
        jPanel.add(lblName);
        jPanel.add(lblSteckeBis);
        jPanel.add(lblKM);
        jPanel.add(txaTourList);

        jPanel.setMinimumSize(new Dimension(500, 350));
        jPanel.setVisible(true);

        //Lade automatisch alle Touren aus Speicher
        //management.ladeTouren();

        return jPanel;
    }

}
