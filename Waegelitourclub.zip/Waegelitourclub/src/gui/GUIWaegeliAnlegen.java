package gui;

import verwaltung.LoginVerwaltung;
import verwaltung.WaegeliVerwaltung;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Created by Jannik on 19.01.2017.
 */
public class GUIWaegeliAnlegen implements ActionListener {

    JFrame jFrame = new JFrame("Waegeli anlegen");
    WaegeliVerwaltung management = new WaegeliVerwaltung();
    LoginVerwaltung managementLogin = new LoginVerwaltung();

    private JLabel lblHeader = new JLabel("Anlegen eines Waegelis");
    private JLabel lblWaegelinutzer = new JLabel("Waegelinutzer: ");
    private JLabel lblWaegeliname = new JLabel("Waegeliname: ");
    private JLabel lblWaegelifarbe = new JLabel("Waegelifarbe: ");
    private JLabel lblWaegelitreibstoff = new JLabel("Waegelitreibstoff: ");
    private JLabel lblWaegelistaerke = new JLabel("Waegelistärke: ");
    private JLabel lblWaegelinutzerAnzeige = new JLabel();
    private JTextField txfWaegeliname = new JTextField();
    private JTextField txfWaegelifarbe = new JTextField();
    private JTextField txfWaegelitreibstoff = new JTextField();
    private JFormattedTextField txfWaegelistaerke = new JFormattedTextField(NumberFormat.getIntegerInstance());

    private JLabel lblWaegelibild = new JLabel();
    private JCheckBox jcbStandardWagen = new JCheckBox("Standard-Waegeli");
    private JButton btnSpeichern = new JButton("Speichern");
    private JButton btnSetzeBild = new JButton("Bild setzen");

    public void baueGUI() throws Exception {

        jFrame.setSize(500, 350);
        jFrame.setLayout(null);

        lblWaegelinutzerAnzeige.setText(managementLogin.getUsername());
        
        lblHeader.setBounds(150, 10, 150, 20);
        lblWaegelibild.setBounds(25, 75, 225, 150);
        btnSetzeBild.setBounds(25, 275, 150, 30);
        jcbStandardWagen.setBounds(200, 275, 150, 30);
        btnSpeichern.setBounds(300, 200, 150, 30);
        lblWaegelinutzer.setBounds(260, 75, 120, 20);
        lblWaegeliname.setBounds(260, 100, 120, 20);
        lblWaegelifarbe.setBounds(260, 125, 120, 20);
        lblWaegelitreibstoff.setBounds(260, 150, 120, 20);
        lblWaegelistaerke.setBounds(260, 175, 120, 20);
        lblWaegelinutzerAnzeige.setBounds(370, 75, 100, 20);
        txfWaegeliname.setBounds(370, 100, 100, 20);
        txfWaegelifarbe.setBounds(370, 125, 100, 20);
        txfWaegelitreibstoff.setBounds(370, 150, 100, 20);
        txfWaegelistaerke.setBounds(370, 175, 100, 20);

        jFrame.add(lblHeader);
        jFrame.add(lblWaegelinutzer);
        jFrame.add(lblWaegeliname);
        jFrame.add(lblWaegelifarbe);
        jFrame.add(lblWaegelitreibstoff);
        jFrame.add(lblWaegelistaerke);
        jFrame.add(lblWaegelinutzerAnzeige);
        jFrame.add(txfWaegeliname);
        jFrame.add(txfWaegelifarbe);
        jFrame.add(txfWaegelitreibstoff);
        jFrame.add(txfWaegelistaerke);
        jFrame.add(btnSpeichern);
        jFrame.add(btnSetzeBild);
        jFrame.add(jcbStandardWagen);
        jFrame.add(lblWaegelibild);

        btnSpeichern.addActionListener(this);
        btnSetzeBild.addActionListener(this);

        jFrame.setMaximumSize(new Dimension(500, 350));
        jFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        jFrame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSpeichern) {
            if (txfWaegeliname.getText() != null || txfWaegelifarbe.getText() != null ||
                    txfWaegelitreibstoff.getText() != null || txfWaegelistaerke.getText() != null) {
                try {
                    management.speichereWaegeli(lblWaegelinutzerAnzeige.getText(), txfWaegeliname.getText(),
                        txfWaegelifarbe.getText(), txfWaegelitreibstoff.getText(),
                        new Integer(txfWaegelistaerke.getText()), management.getWaegelis());
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
                JOptionPane.showMessageDialog(null, "Der Waegeli wurde gespeichert.");
                jFrame.dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Es müssen alle Felder ausgefüllt sein.");
            }
        }
        if (e.getSource() == btnSetzeBild) {
            if (!jcbStandardWagen.isSelected()) {
                try {
                    lblWaegelibild.setIcon(management.setImageIcon(false));
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            } else {
                try {
                    lblWaegelibild.setIcon(management.setImageIcon(true));
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }

        }
    }
}
