package gui;

import verwaltung.LoginVerwaltung;

import javax.swing.*;
import java.awt.*;

/**
 * Created by Jannik on 19.01.2017.
 */
public class GUIVerwaltung {

    public JFrame jFrame = new JFrame("Waegelitourclub");
    private GUIAdminTour guiAdminTour = new GUIAdminTour();
    private GUIAdmin guiAdmin = new GUIAdmin();
    private GUITour guiTour = new GUITour();
    private GUIWaegeli guiWaegeli = new GUIWaegeli();
    private LoginVerwaltung managementLogin = new LoginVerwaltung();

    public void baueGUI() throws Exception {

        jFrame.setSize(550, 450);
        jFrame.setLayout(null);

        JTabbedPane jTabbedPane = new JTabbedPane(JTabbedPane.TOP, JTabbedPane.WRAP_TAB_LAYOUT);
        jTabbedPane.addTab("Tourübersicht", guiTour.baueGUI());
        jTabbedPane.addTab("Waegeliverwaltung", guiWaegeli.baueGUI());

        if (managementLogin.isAdmin()) {
            jTabbedPane.addTab("Admintourverwaltung", guiAdminTour.baueGUI());
            jTabbedPane.addTab("Adminverwaltung", guiAdmin.baueGUI());
        }
        jTabbedPane.setBounds(5, 5, 500, 350);

        jFrame.add(jTabbedPane);

        jFrame.setMinimumSize(new Dimension(510, 410));
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setVisible(true);

    }

}
