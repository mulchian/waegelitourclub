package verwaltung;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by Jannik on 19.01.2017.
 */
public class AdminTourVerwaltung extends TourVerwaltung {

    public void fuegeTourHinzu(ArrayList<String> txaTouren, String tourName, String tourVon, String tourBis, String tourKm) throws IOException {
        speicher.setTour(txaTouren, tourName, tourVon, tourBis, tourKm);
    }

    public ArrayList<String> getTouren() throws Exception {
        return super.getTouren();
    }

}
