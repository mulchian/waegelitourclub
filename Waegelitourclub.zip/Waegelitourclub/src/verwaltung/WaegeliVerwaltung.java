package verwaltung;

import klassen.Waegeli;
import speicher.Speicher;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by Jannik on 19.01.2017.
 */
public class WaegeliVerwaltung {

    private Waegeli waegeli;
    private Speicher speicher = new Speicher();
    private File waegeliFile;
    private String pathname = "assets\\standardWagen.jpg";

    public void speichereWaegeli(String waegelinutzer, String waegeliname, 
            String waegelifarbe, String waegelitreibstoff, 
            Integer waegelistaerke, ArrayList<String> waegeliListe)
            throws IOException {
        waegeli = new Waegeli(waegelinutzer, waegeliname, waegelifarbe, 
                waegelitreibstoff, waegelistaerke, waegeliFile);
        speicher.setWaegelis(waegeli, waegeliListe);
    }

    public ArrayList<String> getWaegelis() throws Exception {
        ArrayList<String> waegeliListe = speicher.getWaegelis();
        return waegeliListe;
    }
    
    public ImageIcon setImageIcon(String pfad) throws Exception {
        ImageIcon imageIcon;
        
        if (pfad != null) {
            imageIcon = new ImageIcon(ImageIO.read(new File(pfad))
                    .getScaledInstance(225, 150, Image.SCALE_AREA_AVERAGING));
        } else {
            imageIcon = new ImageIcon(ImageIO.read(new File(pathname))
                    .getScaledInstance(225, 150, Image.SCALE_AREA_AVERAGING));
        }
        
        return imageIcon;
    }
    
    public ImageIcon setImageIcon(boolean istStandard) throws Exception {

        ImageIcon imageIcon;

        //ImageBuilder
        if (istStandard) {
            imageIcon = new ImageIcon(ImageIO.read(new File(pathname))
                    .getScaledInstance(225, 150, Image.SCALE_AREA_AVERAGING));
        } else {
            JFileChooser jFileChooser = new JFileChooser("assets\\");
            jFileChooser.setFileFilter(new FileNameExtensionFilter("Images", "jpg", "jpeg", "png"));
            int state = jFileChooser.showOpenDialog(null);
            if (state == JFileChooser.APPROVE_OPTION) {
                File file = jFileChooser.getSelectedFile();
                this.speichereFile(file);
                imageIcon = new ImageIcon(ImageIO.read(file).getScaledInstance(225, 150, Image.SCALE_AREA_AVERAGING));
            } else {
                JOptionPane.showMessageDialog(null, "Auswahl abgebrochen." +
                        "\r\nStandard-Bild wurde ausgewählt.");
                imageIcon = new ImageIcon(ImageIO.read(new File(pathname))
                        .getScaledInstance(225, 150, Image.SCALE_AREA_AVERAGING));
            }
        }
        return imageIcon;
    }

    private void speichereFile(File file) {
        this.waegeliFile = file;
    }

    
}
