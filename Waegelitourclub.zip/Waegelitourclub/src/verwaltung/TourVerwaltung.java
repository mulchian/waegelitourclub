package verwaltung;

import speicher.Speicher;

import java.util.ArrayList;

/**
 * Created by Jannik on 20.01.2017.
 */
public abstract class TourVerwaltung {

    protected Speicher speicher = new Speicher();

    public ArrayList<String> getTouren() throws Exception {
        ArrayList<String> tourenListe = speicher.getTouren();
        return tourenListe;
    }

}
