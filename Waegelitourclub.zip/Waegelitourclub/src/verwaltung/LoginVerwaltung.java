package verwaltung;

import klassen.Admin;
import klassen.Mitglied;
import speicher.Speicher;

/**
 * Created by Fabian on 19.01.2017.
 */
public class LoginVerwaltung {

    private Speicher speicher;
    private String username;
    private String password;

    public LoginVerwaltung() {
    }

    public boolean isAdmin() {
        return true;
    }

    private Mitglied convertUser(String pUsername) {
        return null;
    }

    private Admin convertAdmin(String pUsername) {
        return null;
    }

    public void login(String pUsername, String pPasswort) {
        this.username = pUsername;
        this.password = pPasswort;
    }

    public void openVerwaltung() {

    }

    public void openJFrame() {

    }

    public String getUsername() {
        return username;
    }

}
