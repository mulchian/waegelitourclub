package verwaltung;

import java.util.ArrayList;

/**
 * Created by Jannik on 19.01.2017.
 */
public class MitgliedTourVerwaltung extends TourVerwaltung {

    public ArrayList<String> getTouren() throws Exception {
        return super.getTouren();
    }

}
