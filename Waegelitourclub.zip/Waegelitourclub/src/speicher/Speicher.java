package speicher;

import klassen.Person;
import klassen.Waegeli;

import java.io.*;
import java.util.ArrayList;

/**
 * Created by Jannik on 19.01.2017.
 */
public class Speicher {

    /*
	 * evtl Singleton implementieren, damit nur 1 Speicher über
	 * das gesamte Projekt besteht
	 */

    private File touren = new File("assets\\Touren.txt");
    private File waegelis = new File("assets\\Waegelis.txt");

    public Person getUserData() throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(
                new File("K:\\03_Vereinsverwaltung\\Team F\\Datenbank\\")));
        br.close();
        return null;
    }

    public void setWaegelis(Waegeli waegeli, ArrayList<String> waegeliListe) throws IOException {
        BufferedWriter bw = new BufferedWriter((new FileWriter(waegelis)));

        for (String string : waegeliListe) {
            bw.write(string);
            bw.newLine();
        }
        bw.write(waegeli.getWaegeliNutzer() + "|");
        bw.write(waegeli.getName() + "|");
        bw.write(waegeli.getFarbe() + "|");
        bw.write(waegeli.getTreibstoff() + "|");
        bw.write(waegeli.getWaegeliStaerke() + "|");
        bw.write(waegeli.getWaegeliFile().getPath() + "|");
        bw.newLine();

        bw.close();
    }

    public ArrayList<String> getWaegelis() throws Exception {
        ArrayList<String> waegeliListe = new ArrayList<String>();
        BufferedReader br = new BufferedReader(new FileReader(waegelis));
        String zeile = "";

        while((zeile = br.readLine()) != null) {
            waegeliListe.add(zeile);
        }
        
        br.close();
        return waegeliListe;
    }
    
    public void setTour(ArrayList<String> txaTouren, String tourName, String tourVon, String tourBis, String tourKm) throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter(touren));

        for (String tourZeile : txaTouren) {
            bw.write(tourZeile);
            bw.newLine();
        }

        bw.write(String.format("%1$-10s", tourName) + "|");
        bw.write(String.format("%1$-10s", tourVon) + "|");
        bw.write(String.format("%1$-10s", tourBis) + "|");
        bw.write(String.format("%1$-10s", tourKm) + "|");
        bw.newLine();

        bw.close();
    }

    public ArrayList<String> getTouren() throws Exception {
        ArrayList<String> tourenListe = new ArrayList<String>();
        BufferedReader br = new BufferedReader(new FileReader(touren));
        String zeile = "";

        while((zeile = br.readLine()) != null) {
            tourenListe.add(zeile);
        }
        
        br.close();
        return tourenListe;
    }

    
}
