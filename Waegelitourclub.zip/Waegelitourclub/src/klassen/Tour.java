package klassen;

/**
 * Created by Jannik on 19.01.2017.
 */
public class Tour {

    private String name;
    private String streckeVon;
    private String streckeBis;
    private int km;

    public Tour() {
    }

}
