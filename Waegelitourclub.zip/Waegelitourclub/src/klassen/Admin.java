package klassen;

/**
 * Created by Jannik on 19.01.2017.
 */
public class Admin extends Person {

    public Admin(String username, String password) {
        super(username, password);
    }

    @Override
    public void anmelden() {
        // TODO Auto-generated method stub
        super.anmelden();
    }

    @Override
    public Person abmelden() {
        // TODO Auto-generated method stub
        return super.abmelden();
    }

    public void oeffneTourVerwaltung() {

    }

}
