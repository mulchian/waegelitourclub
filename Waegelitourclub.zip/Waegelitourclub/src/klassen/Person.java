package klassen;

/**
 * Created by Jannik on 19.01.2017.
 */
public abstract class Person {

    public String username;
    protected String password;

    public Person(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public void anmelden() {

    }

    public Person abmelden() {
        return null;
    }

}
