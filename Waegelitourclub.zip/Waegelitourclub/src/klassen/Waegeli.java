package klassen;

import java.awt.*;
import java.io.File;

/**
 * Created by Fabian on 19.01.2017.
 */
public class Waegeli {

    private String waegeliNutzer;
    private Integer waegeliStaerke;
    private String name;
    private String farbe;
    private String treibstoff;
    private File waegeliFile;

    public Waegeli() {
    }

    public Waegeli(String waegelinutzer, String waegeliname, String waegelifarbe, String waegelitreibstoff,
                   Integer waegelistaerke, File waegeliFile) {
        this.waegeliNutzer = waegelinutzer;
        this.name = waegeliname;
        this.farbe = waegelifarbe;
        this.treibstoff = waegelitreibstoff;
        this.waegeliStaerke = waegelistaerke;
        this.waegeliFile = waegeliFile;
    }

    public String getWaegeliNutzer() {
        return waegeliNutzer;
    }

    public Integer getWaegeliStaerke() {
        return waegeliStaerke;
    }

    public String getName() {
        return name;
    }

    public String getFarbe() {
        return farbe;
    }

    public String getTreibstoff() {
        return treibstoff;
    }

    public File getWaegeliFile() {
        return waegeliFile;
    }
}
